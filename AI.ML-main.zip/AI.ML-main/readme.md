# Artificial Intelligence & Machine Learning Lab

![made-with-python](https://img.shields.io/badge/Made%20with-Python-0078D4.svg)
![numpy](https://img.shields.io/badge/Numpy-777BB4?logo=numpy&logoColor=white)
![pandas](https://img.shields.io/badge/Pandas-2C2D72?logo=pandas&logoColor=white)
![scikit-learn](https://img.shields.io/badge/Scikit_learn-0078D4?logo=scikit-learn&logoColor=white)
![vscode](https://img.shields.io/badge/Visual_Studio_Code-0078D4?logo=visual%20studio%20code&logoColor=white)

This repository contains all my source code for practicing MCA Semester 3 AI & ML lab assignments in Python programming language.
